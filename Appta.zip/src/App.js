import './App.css';
import 'tailwindcss/tailwind.css';
import Sidebar from './Components/Sidebar';
import Trial from './Components/Trial';

function App() {
  return (
    <div className="App">
  
    {/* <Sidebar /> */}
    <Trial/>
    </div>
  );
}

export default App;
