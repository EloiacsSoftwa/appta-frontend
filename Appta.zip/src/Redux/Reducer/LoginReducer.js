const initialState = {

    email: '',
    password: '',
    isLoggedIn: false,
    errorEmail: '',
    errorPassword: '',
    errorMessage: '',
    status: 0,
    loginInformation: [],
    JWTtoken:'',    
 }
 const LoginReducer = (state = initialState, action) => {
 
    switch (action.type) {
       case 'ERROR':
          return { ...state, errorMessage: action.payload }
       case 'LOGIN-INFO':
          return { ...state, loginInformation: action.payload.response.Data, email: action.payload.response.email, password: action.payload.response.password, errorEmail: '', errorPassword: '', errorMessage: '', statusCode: action.payload.statusCode, JWTtoken:action.payload.response.token }
       case 'ERROR_EMAIL':
          return { ...state, errorEmail: action.payload }
       case 'ERROR_PASSWORD':
          return { ...state, errorPassword: action.payload }
       case 'CLEAR_EMAIL_ERROR':
          return { ...state, errorEmail: '' }
       case 'CLEAR_PASSWORD_ERROR':
          return { ...state, errorPassword: '' }
       case 'LOGIN-SUCCESS':
          return { ...state, isLoggedIn: true }
     
      
     
 
 
    }
 
    return state
 }
 export default LoginReducer;