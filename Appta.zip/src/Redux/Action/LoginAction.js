import AxiosConfig from "../../WebService/AxiosConfig";




export async function login(payload) {
//   return await AxiosConfig.post('/auth/login', {
//  email, password
//   })
 return await AxiosConfig.post('/auth/login', payload);
}