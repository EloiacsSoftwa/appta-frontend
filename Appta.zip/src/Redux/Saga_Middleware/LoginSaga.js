import { call, takeEvery, put } from 'redux-saga/effects';
import { login } from '../Action/LoginAction';




// let cookies = new Cookies();


function* Login(args) {

  try {

    const response = yield call(login, args.payload);
    console.log("ssssssssss",response.status,response.statusCode)
    if (response.status === 200 || response.statusCode === 200) {
      yield put({ type: 'LOGIN-INFO', payload:{ response:response.data,statusCode:response.status || response.statusCode } });
          }
    
  } catch (error) {
    // yield put({ type: 'ERROR', payload: 'An error occurred.' });
  }
}







  function* LoginSaga() {
    yield takeEvery('LOGININFO', Login)
    
  }
  export default LoginSaga;